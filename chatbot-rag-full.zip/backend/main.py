import os
from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from rag_chain import create_chain
from ingest import ingest_file

load_dotenv()

app = FastAPI(title='Chatbot RAG')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

chain = create_chain()

class Query(BaseModel):
    query: str

@app.post('/ask')
async def ask(q: Query):
    result = chain(q.query)
    # result is a dict with 'result' and 'source_documents' (LangChain RetrievalQA)
    return {'answer': result.get('result'), 'sources': [d.metadata for d in result.get('source_documents', [])]}

@app.post('/upload')
async def upload(file: UploadFile = File(...)):
    save_dir = os.path.join('data','uploads')
    os.makedirs(save_dir, exist_ok=True)
    path = os.path.join(save_dir, file.filename)
    with open(path, 'wb') as f:
        f.write(await file.read())
    ingest_file(path)
    return {'message': f'Arquivo {file.filename} salvo e indexado.'}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run('backend.main:app', host='0.0.0.0', port=8000, reload=True)
