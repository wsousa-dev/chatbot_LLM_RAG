# helper utilities (placeholder) - expand as needed
def clean_text(s: str) -> str:
    return ' '.join(s.split())
