from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
import os
from dotenv import load_dotenv

load_dotenv()

DB_PATH = os.getenv('CHROMA_PERSIST_DIRECTORY', './vectordb')

def create_chain():
    embeddings = OpenAIEmbeddings()
    vectordb = Chroma(persist_directory=DB_PATH, embedding_function=embeddings)
    retriever = vectordb.as_retriever(search_kwargs={'k':4})
    llm = OpenAI(temperature=0)
    chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever, chain_type='stuff', return_source_documents=True)
    return chain
