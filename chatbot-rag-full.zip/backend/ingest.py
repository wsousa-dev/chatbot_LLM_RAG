import os
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.document_loaders import PyPDFLoader, TextLoader
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from dotenv import load_dotenv

load_dotenv()
DB_PATH = os.getenv('CHROMA_PERSIST_DIRECTORY', './vectordb')
DATA_DIR = os.path.join('data','uploads')

def load_document(path):
    if path.lower().endswith('.pdf'):
        loader = PyPDFLoader(path)
    else:
        loader = TextLoader(path, encoding='utf-8')
    return loader.load()

def ingest_file(path):
    docs = load_document(path)
    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=150)
    chunks = splitter.split_documents(docs)
    embeddings = OpenAIEmbeddings()
    db = Chroma.from_documents(documents=chunks, embedding=embeddings, persist_directory=DB_PATH)
    db.persist()
    print(f'Indexed {len(chunks)} chunks from {path}')

if __name__ == '__main__':
    # index all files in data/uploads
    os.makedirs(DATA_DIR, exist_ok=True)
    for f in os.listdir(DATA_DIR):
        ingest_file(os.path.join(DATA_DIR,f))
