async function sendMessage() {
  const prompt = document.getElementById('prompt').value;
  if (!prompt) return;
  appendMessage('Você', prompt);
  document.getElementById('prompt').value = '';
  try {
    const res = await fetch('http://localhost:8000/ask', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({query: prompt})
    });
    const data = await res.json();
    appendMessage('Bot', data.answer || JSON.stringify(data));
  } catch (err) {
    appendMessage('Erro', err.message || String(err));
  }
}

function appendMessage(who, text) {
  const chat = document.getElementById('chat');
  const el = document.createElement('div');
  el.innerHTML = '<b>'+who+':</b> '+text;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
}

async function uploadFile() {
  const fileInput = document.getElementById('fileInput');
  if (!fileInput.files.length) return alert('Escolha um arquivo');
  const form = new FormData();
  form.append('file', fileInput.files[0]);
  const res = await fetch('http://localhost:8000/upload', {method:'POST', body: form});
  const data = await res.json();
  alert(data.message || 'OK');
}
