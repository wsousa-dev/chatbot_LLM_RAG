#!/bin/bash
# Usage: ./scripts/ingest.sh path/to/file.pdf
FILE=$1
if [ -z "$FILE" ]; then
  echo 'Provide a file to ingest'
  exit 1
fi
curl -v -F "file=@${FILE}" http://localhost:8000/upload
