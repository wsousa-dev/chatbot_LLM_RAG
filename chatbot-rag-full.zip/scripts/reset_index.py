import shutil, os
DB_PATH = './vectordb'
if os.path.exists(DB_PATH):
    shutil.rmtree(DB_PATH)
    print('Index removed')
else:
    print('No index present')
